const express = require('express');
const dotenv = require('dotenv');
const axios = require('axios');

dotenv.config();
const app = express();
app.use(express.json({ limit: '50mb' }));

const SYSTEM_PROMPT = `You are a premium financial data parser. Extract financial data from the provided Thai bank slip, receipt, or text.
Return ONLY a valid JSON object. Do not include markdown blocks like \\`\\`\\`json or any conversational text.

The JSON structure must be:
{
  "transaction_date": "YYYY-MM-DD",
  "transaction_time": "HH:MM",
  "amount": 0.00,
  "sender_name": "Name or null",
  "receiver_name": "Name or null",
  "bank_name": "Bank Name or null",
  "items": [],
  "category": "Auto-categorized category (e.g., Food, Travel, Utilities, Shopping, Entertainment)"
}`;

app.get('/api/health', (req, res) => {
  res.json({ status: "alive", provider: process.env.ACTIVE_PROVIDER || "not_set" });
});

app.post('/api/parse-receipt', async (req, res) => {
  try {
    const { data, isImage } = req.body;
    if (!data) return res.status(400).json({ success: false, error: "Missing data" });

    const activeProvider = process.env.ACTIVE_PROVIDER || 'gemini';
    let result = {};

    if (activeProvider === 'gemini') {
      const apiKey = process.env.GEMINI_API_KEY;
      const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`;
      const contents = [{ parts: [{ text: SYSTEM_PROMPT }, { inlineData: { mimeType: "image/jpeg", data: data } }] }];
      const response = await axios.post(url, { contents });
      result = JSON.parse(response.data.candidates[0].content.parts[0].text.trim());
    } else if (activeProvider === 'openrouter') {
      const apiKey = process.env.OPENROUTER_API_KEY;
      const url = "https://openrouter.ai/api/v1/chat/completions";
      const messages = isImage 
        ? [{ role: "user", content: [{ type: "text", text: SYSTEM_PROMPT }, { type: "image_url", image_url: { url: `data:image/jpeg;base64,{data}` } }] }]
        : [{ role: "system", content: SYSTEM_PROMPT }, { role: "user", content: data }];
      const response = await axios.post(url, { model: "google/gemini-flash-1.5", messages }, { headers: { "Authorization": `Bearer ${apiKey}` } });
      result = JSON.parse(response.data.choices[0].message.content.trim());
    } else if (activeProvider === 'groq') {
      if (isImage) return res.status(400).json({ success: false, error: "Groq text-only requires frontend OCR text" });
      const apiKey = process.env.GROQ_API_KEY;
      const url = "https://api.groq.com/openai/v1/chat/completions";
      const response = await axios.post(url, {
        model: "llama-3.1-8b-instant",
        messages: [{ role: "system", content: SYSTEM_PROMPT }, { role: "user", content: data }],
        response_format: { type: "json_object" }
      }, { headers: { "Authorization": `Bearer ${apiKey}` } });
      result = JSON.parse(response.data.choices[0].message.content.trim());
    }

    return res.json({ success: true, provider: activeProvider, data: result });
  } catch (error) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = app;
